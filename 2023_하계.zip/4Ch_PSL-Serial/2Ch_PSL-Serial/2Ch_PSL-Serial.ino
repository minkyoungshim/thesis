#include <TimerOne.h>

int analogPin0 = 0;
int analogPin1 = 1;
int blueLedPin = 5; // 파란색 LED 핀 번호
int greenLedPin = 6; // 초록색 LED 핀 번호
int redLedPin = 7; // 빨간색 LED 핀 번호

unsigned long previousMillis = 0; //사용한 이전 횟수 처음에는 0으로 초기화
const long interval = 4000; // 1분을 밀리초 단위로 표현
bool blueLedState = false;  //파란 LED가 켜진지 확인
int blueLedOnCount = 0; //파란 LED가 켜진 횟수 처음이니까 0으로 초기화

void setup() {
  Serial.begin(9600);
  pinMode(blueLedPin, OUTPUT);
  pinMode(greenLedPin, OUTPUT);
  pinMode(redLedPin, OUTPUT);
}

void loop() {
  if(blueLedOnCount >10) { // LED가 횟수만큼 켜진 후에는 모든 LED를 꺼둡니다.
    digitalWrite(blueLedPin, LOW);
    digitalWrite(greenLedPin, LOW);
    digitalWrite(redLedPin, LOW);
    return;
  }

  unsigned long currentMillis = millis(); //초를 가져와서 CURRENTMILLIS에 저장
  
  if (currentMillis - previousMillis >= interval) { //현재 시간하고 이전시간하고 설정된 간격이 같은지 확인
    previousMillis = currentMillis; //이전시간을 현재시간으로 설정
    blueLedState = !blueLedState; // 파란색 LED 상태 반전
    digitalWrite(blueLedPin, blueLedState ? HIGH : LOW);  //파란색 LED의 상태를 실제로 제어
    if(blueLedState) {
      blueLedOnCount++; //LED 켜진 카운트 증가
    }
  }

  if (blueLedState) { //LED 실행되었을때
    int reading0 = analogRead(analogPin0); 
    int reading1 = analogRead(analogPin1);  
    float Voltage0 = (float)reading0 / 1023 * 5;
    float Voltage1 = (float)reading1 / 1023 * 5;
    String str = String(Voltage0, 3) + "," + String(Voltage1, 3);
    Serial.println(str);  //원래 제공된 코드

    if (Voltage1 > 1.68) {  
      digitalWrite(greenLedPin, HIGH); // 초록색 LED 켜기
      digitalWrite(redLedPin, LOW); // 빨간색 LED 끄기
    } else {
      digitalWrite(greenLedPin, LOW); // 초록색 LED 끄기
      digitalWrite(redLedPin, HIGH); // 빨간색 LED 켜기
    }
  } else {
    digitalWrite(greenLedPin, LOW); // 파란색 LED가 꺼져 있을 경우, 초록색 LED도 꺼져 있어야 함
    digitalWrite(redLedPin, LOW); // 파란색 LED가 꺼져 있을 경우, 빨간색 LED도 꺼져 있어야 함
  }
}
