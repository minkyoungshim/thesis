import serial
import time
from datetime import datetime

arduino = serial.Serial('COM3', 9600)

filename = input("저장할 파일의 이름을 입력해주세요: ")

with open(filename + '.csv', 'w') as f:
    while True:
        data = arduino.readline() 
        if data:
            now = datetime.now() 
            data_str = data.decode('utf-8').strip()  
            f.write(now.strftime("%Y-%m-%d %H:%M:%S") + ', ' + data_str + '\n')  
        time.sleep(1) 
